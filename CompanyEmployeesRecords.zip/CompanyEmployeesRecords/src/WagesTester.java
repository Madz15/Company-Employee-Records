///**public class WagesTester
//{
//    public static void main(String[] args)
//    {
//        Wages w1 = new Wages ("", 1500);
//
//        //code to interrogate object data
//        System.out.println("Month: "+ w1.getMonth());
//        System.out.println("Amount: " + w1.getAmount());
//
//    }
//}
//*/
